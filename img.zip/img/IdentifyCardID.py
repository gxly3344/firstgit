import pytesseract
import cv2	

#在控制台输出中文用的，
import io
import sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8')


pic_path = '3.png'
image = cv2.imread(pic_path)
text = pytesseract.image_to_string(image)

IDnum = text.split("\n")[-1].split(' ')[-1]
if (len(IDnum) > 18):   ## 去除不必要的空格
    IDnum = IDnum.replace(" ","")
print("公民身份证号:",IDnum)
